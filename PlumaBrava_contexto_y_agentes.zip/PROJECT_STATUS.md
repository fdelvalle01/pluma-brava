# Pluma Brava — estado y siguiente tarea

**Última actualización de este registro:** 2026-10-03.  
**Origen del estado inicial:** conversación y capturas de Francisco; no una inspección directa del repositorio.  
**Prioridad:** verificar el salto y las colisiones, conservando el movimiento horizontal que ya funciona.

## 1. Confirmado hasta ahora

| Elemento | Evidencia disponible |
| --- | --- |
| Proyecto `PlumaBrava` creado en GameMaker. | Capturas del editor y ejecución. |
| Sprite `spr_player` de 32 × 32, dibujado a mano. | Captura del editor de imagen; paloma visible. |
| Origen del jugador configurado abajo al centro durante la preparación. | Confirmación del usuario; volver a comprobar el valor actual en el recurso. |
| Recursos `spr_ground`, `obj_player`, `obj_solid` y `Room1`. | Visibles en el navegador de activos. |
| Eventos Crear y Paso en `obj_player`. | Visibles en el editor; leer su GML actual antes de cambiarlo. |
| Suelo y dos plataformas elevadas colocados en el escenario. | Captura de la ventana del juego. |
| El proyecto compiló y abrió una ventana de juego. | Confirmación explícita de Francisco después de la reparación con Codex. |
| La paloma se mueve horizontalmente. | Reporte explícito: «solo me puedo mover en x». |

El prototipo ya visible no equivale a que todas las colisiones estén probadas. La captura muestra a la paloma junto al suelo, pero no demuestra la respuesta al saltar, aterrizar o golpear una plataforma.

## 2. Pendiente de verificar

- Si Espacio ya activa el salto al tener foco la ventana del juego.
- Si la gravedad y la detección de apoyo funcionan correctamente.
- Si se aterriza sobre suelo y plataformas sin atravesarlos.
- Si las colisiones laterales y contra la parte inferior de los bloques funcionan.
- Si el jugador puede reaparecer al caer fuera del escenario; no hay implementación confirmada.
- Si existe orientación izquierda/derecha; no hay implementación confirmada.
- Los valores reales de la room, cámara y escalado.

**No registrar el salto como roto ni como terminado sin comprobarlo.** El mensaje del usuario no confirma qué teclas probó. El control que se había propuesto era Espacio, no flecha arriba.

## 3. Inventario inicial para localizar recursos

| Recurso | Tipo | Papel esperado |
| --- | --- | --- |
| `PlumaBrava.yyp` | Proyecto | Entrada del proyecto. |
| `spr_player` | Sprite | Paloma dibujada por Francisco. |
| `obj_player` | Objeto | Jugador; utiliza `spr_player`. |
| `spr_ground` | Sprite | Bloque de suelo. |
| `obj_solid` | Objeto | Bloques usados por las colisiones. |
| `Room1` | Room | Escenario de pruebas actual. |

Rutas habituales que el agente debe confirmar, no crear a ciegas:

```text
objects/obj_player/obj_player.yy
objects/obj_player/Create_0.gml
objects/obj_player/Step_0.gml
objects/obj_solid/obj_solid.yy
sprites/spr_player/spr_player.yy
sprites/spr_ground/spr_ground.yy
rooms/Room1/Room1.yy
```

En la preparación se utilizaron variables llamadas `hsp`, `vsp`, `move_speed`, `jump_speed` y `gravity_force`. Los valores de referencia vistos/propuestos fueron `2.5`, `-6` y `0.3` para las últimas tres. El código real del repositorio manda: no sustituirlo por un ejemplo de la conversación sin leerlo.

## 4. Entorno observado

Windows, GameMaker LTS 2026, edición GML y VS Code. Las capturas iniciales mostraron IDE `2026.0.0.16` y los logs runtime `2026.0.0.23`.

Son versiones observadas, no una orden para instalar, actualizar o fijar versiones. La configuración actual debe inspeccionarse localmente. Los agentes no conocen automáticamente las rutas o permisos disponibles en otra sesión.

## 5. Incidencia de compilación ya superada

Al ejecutar y al limpiar apareció:

```text
GMAssetCompiler.dll exited with non-zero status (-1)
FAILED: Run Program Complete
FAILED : Clean Program Complete
```

La pestaña de errores de compilación estaba vacía. Después de la revisión/reparación con Codex, Francisco confirmó que el proyecto compiló y arrancó.

**No se dispone aquí del diagnóstico completo ni del diff de esa reparación.** No atribuir retrospectivamente el problema al antivirus, a la caché o al runtime como si se hubiera demostrado. No rehacer la reparación ni borrar archivos del entorno sin una nueva evidencia de fallo.

Una salida genérica `-1` y una pestaña vacía no bastan para descartar errores de recursos, metadatos o código.

## 6. Backlog de avance

Estados: `pendiente`, `en_curso`, `implementado_sin_verificar`, `verificado` y `bloqueado`. Solo `verificado` significa que hay evidencia de que se cumple el resultado esperado.

| ID | Tarea | Estado inicial | Resultado esperado |
| --- | --- | --- | --- |
| PB-001 | Base del proyecto y ejecución. | verificado | Se abre el juego con paloma, bloques y movimiento horizontal. |
| PB-002 | Verificar/corregir salto, gravedad y colisiones. | pendiente | La paloma camina, salta y aterriza de forma controlada. |
| PB-003 | Orientación al moverse. | pendiente | Mira hacia el lado correcto y mantiene la orientación al detenerse. |
| PB-004 | Reaparición básica al caer. | pendiente | Puede retomarse la prueba después de salir del escenario. |
| PB-005 | Encuadre y escalado del prototipo. | pendiente | El jugador y el espacio jugable tienen una escala acordada y legible. |
| PB-006 | Disparo de pistola y objetivo simple. | pendiente | El proyectil sale hacia el lado correcto, impacta y se elimina. |
| PB-007 | Vida, daño y primer enemigo. | pendiente | Hay un encuentro básico con posibilidad de perder y reintentar. |
| PB-008 | Completazo y cambio de arma. | pendiente | Recoger la segunda arma cambia de forma perceptible el ataque. |
| PB-009 | Recorrido corto y segundo enemigo. | pendiente | El escenario enseña las mecánicas de manera gradual. |
| PB-010 | Punto de control y jefe. | pendiente | Combate completo con un ataque inicial, derrota y victoria. |
| PB-011 | Animaciones, audio y ajustes de demo. | pendiente | Demo corta con presentación y respuestas claras. |

Esta tabla expresa un orden propuesto. No autoriza implementar las tareas siguientes ni impide que Francisco cambie la prioridad. Las animaciones pueden incorporarse antes cuando sean útiles.

## 7. Tarea activa siguiente: PB-002

### Objetivo

Determinar si el salto funciona con Espacio y, si hay un fallo, corregirlo con el cambio mínimo, sin perder el movimiento horizontal existente.

### Primera revisión

Leer los eventos actuales de `obj_player` y las referencias a `obj_solid`. Comprobar inicialización, lectura de teclado, condición de apoyo, aplicación de gravedad, desplazamiento vertical y resolución de colisiones.

Consultar sin modificar los recursos necesarios para entender máscaras, origen, física y posición inicial. No deducir esos valores a partir del dibujo solamente.

Antes de reemplazar código, pedir una prueba con la ventana del juego enfocada y Espacio mientras la paloma está sobre el suelo. Si el código ya implementa el comportamiento, no reescribirlo por preferencia de estilo.

### Criterios de aceptación

- [ ] Izquierda y derecha siguen funcionando.
- [ ] Espacio inicia un salto cuando la paloma está apoyada.
- [ ] La gravedad la hace caer y aterrizar sobre un bloque.
- [ ] Presionar Espacio en el aire no introduce un salto adicional.
- [ ] No atraviesa paredes ni la parte inferior de bloques sólidos al probarlos.
- [ ] No queda atascada ni aparecen errores durante la prueba.

### Alcance permitido al solicitar la implementación

GML de los eventos existentes que realmente necesiten cambios. Sin armas, animaciones, cámara, nuevos recursos ni ajustes de arquitectura. Si falta un evento o recurso, detener la implementación y explicar qué debe crear Francisco.

### Verificación y cierre

Registrar por separado revisión estática, compilación y prueba jugable. La implementación queda en `implementado_sin_verificar` hasta comprobar los criterios. Si funciona sin cambios, registrar la prueba y cerrar la tarea sin inventar una modificación.

## 8. Bitácora

### 2026-10-03 — punto de partida

Francisco dibujó la paloma, preparó el suelo y colocó los recursos en el escenario. Se superó una incidencia de compilación con ayuda de Codex. El juego abrió y se confirmó movimiento horizontal. El siguiente paso es verificar el salto, no añadir combate.

## 9. Plantilla para la próxima actualización

Al terminar una tarea, el agente principal actualiza este documento, conserva la historia y deja una sola siguiente acción clara.

```text
Fecha y tarea:
Qué se cambió (o por qué no hizo falta cambiar nada):
Archivos afectados:
Revisión / compilación / prueba jugable: resultado de cada una
Evidencia: comando y salida relevante, o prueba confirmada por Francisco
Estado resultante:
Pendiente y siguiente acción:
```

No marcar pruebas no realizadas ni completar criterios por inferencia. Si la documentación contradice los archivos o una prueba nueva, explicar la diferencia y corregir este registro con esa evidencia.
